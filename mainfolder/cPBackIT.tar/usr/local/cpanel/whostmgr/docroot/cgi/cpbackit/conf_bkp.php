<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css"></link>
</head>
<body>
<div class="headcontent">
        <a href="index.php">cPBackIT - cPanel Remote Backup</a>
</div>
<div class="content">
<?php
$lines = file("/etc/cpbackit/cpbackit.conf");
foreach ($lines as $key) {
$term = explode("=",trim($key));
        if($term[0]=='HOST'){
        		$key_remote_ip=$term[1];
       		}
	elseif( $term[0]=='USER') {
			$key_remote_user=$term[1];
		}
	elseif($term[0]=='PASSWD' ) {
			$key_remote_port=$term[1];
		}
	elseif($term[0]=='FOLDER' ) {
			$key_restination_folder=$term[1];
		}	
        elseif($term[0]=='EMAIL' ) {
                        $key_restinatione_mail=$term[1];
                }

}
?>
<p>
<table border="1" width="100%" color="black">                             
<tr>                                                                      
<td> <font size='2'>                                                                     
<b>Important :</b><i>You need to have one outside ftp and edit on /etc/cpbackit/cpbackit.conf <a href="http://carlos-faustino.com"help me 
developing more</a></i>                           
 </font>              
</td>
</tr>
</table>
</p>
<p>
<form action="conf_bkp_update.php" method="post">
<table border="1" width="100%"  cellspacing="0">
<tr height="40px"  bgcolor="#C1C1C1">
<td width="400px" align="center"><font size="2"><strong>Feature</strong></font><br></td>
<td width="600px" align="center"><font size="2"><strong>Value</font><br></td> 
</tr>
<tr height="30px">
<td width="400px" align="left">IP/Hostname<br /></td>
<td width="600px" align="left"><input type="text" name="key_hname" size="20" value="<?php echo $key_remote_ip; ?>"><br /></td> 
</tr>
<tr height="30px">
<td width="400px" align="left">Username<br /></td>
<td width="600px" align="left"><input type="text" name="key_user" size="20" value="<?php echo $key_remote_user;  ?>"><br />( A remote user , eg:bkpusr)</td> 
</tr>
<tr height="30px">
<td width="400px" align="left">Password<br /></td>
<td width="600px" align="left"><input type="text" name="key_port" size="20" value="<?php echo $key_remote_port;  ?>">(Password stills no encrypted on database)<br  /></td> 
</tr>
<tr height="30px">
<td width="400px" align="left">Folder<br /></td>
<td width="600px" align="left"><input type="text" name="key_folder" size="20" value="<?php echo $key_restination_folder; ?>">(No ending  '/')<br /></td> 
</tr>
<tr height="30px">
<td width="400px" align="left">Folder<br /></td>
<td width="600px" align="left"><input type="text" size="20" value="<?php echo $key_restination_email; ?>">(Email where will be send email)<br /></td>
</tr>


</table><br >

</form>
</p>
<a href="edit_bkp.php">Edit Backup Configuration</a>
</div>
<?php include('footer.php'); ?>
