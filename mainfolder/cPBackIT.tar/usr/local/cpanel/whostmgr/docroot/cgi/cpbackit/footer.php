<div class="footer">
<span id="valid">
Copyright &copy;<a href="http://carlos-faustino.com/"> www.carlos-faustino.com</a> 
</span>
</div>
</body>
</html>
